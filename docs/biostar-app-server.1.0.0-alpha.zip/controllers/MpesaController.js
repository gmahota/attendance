"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mpesa_1 = __importDefault(require("../services/mpesa"));
const receiveMoney = async function (request, response) {
    const { from, reference, transaction, amount } = request.body;
    try {
        const response_mpesa = await mpesa_1.default.set_ReceiveMoney(from, reference, transaction, amount);
        console.log(response_mpesa);
        return response.status(200).json(response_mpesa);
    }
    catch (e) {
        return response.status(401).json({ msg: e });
    }
};
exports.default = {
    receiveMoney
};
