"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.get_Report = exports.get_PunchDailyCard = exports.get_all_PunchDailyCards = void 0;
const punchDailyCard_1 = __importDefault(require("../../services/attendance/punchDailyCard"));
exports.get_all_PunchDailyCards = async (request, response) => {
    const { group, user, dateBegin, dateEnd, department } = request.body;
    const PunchDailyCards = await punchDailyCard_1.default.getAll({
        group,
        user,
        dateBegin,
        dateEnd,
        department
    });
    return response.status(200).json(PunchDailyCards);
};
exports.get_PunchDailyCard = async (request, response) => {
    const { date } = request.body;
    const PunchDailyCard = await punchDailyCard_1.default.getByDate(date);
    if (PunchDailyCard) {
        return response.status(200).json(PunchDailyCard);
    }
    return response.status(404).json({ msg: "no PunchDailyCard with that id" });
};
exports.get_Report = async (request, response) => {
    const { name, type, group, user, dateBegin, dateEnd, department } = request.body;
    const file = await punchDailyCard_1.default.getReport({
        department,
        name,
        type,
        group,
        user,
        dateBegin,
        dateEnd,
    });
    response.status(202).json({ file });
};
