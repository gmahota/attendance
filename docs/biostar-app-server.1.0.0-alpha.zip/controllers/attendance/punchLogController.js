"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.delete_PunchLog = exports.create_PunchLog = exports.get_PunchLog = exports.get_all_PunchLogs = void 0;
const punchLog_1 = __importDefault(require("../../services/attendance/punchLog"));
const punchLog_2 = __importDefault(require("../../models/attendance/punchLog"));
exports.get_all_PunchLogs = async (request, response) => {
    const PunchLogs = await punchLog_1.default.getAll();
    //ExcelPunchLog.fillData(PunchLogs); //fillPunchLog(PunchLogs);
    return response.status(200).json(PunchLogs);
};
exports.get_PunchLog = async (request, response) => {
    const { id } = request.params;
    const PunchLog = await punchLog_1.default.getById(id);
    if (PunchLog) {
        return response.status(200).json(PunchLog);
    }
    return response.status(404).json({ msg: "no PunchLog with that id" });
};
exports.create_PunchLog = async (request, response) => {
    const { userId, userName, date, json } = await request.body;
    try {
        let item = {
            id: 0,
            userId,
            userName,
            date,
            json
        };
        item = await punchLog_1.default.create(item);
        return response.status(200).json(punchLog_2.default);
    }
    catch (e) {
        return response.status(404).json({ msg: "error to create a PunchLog with that i", error: e });
    }
};
exports.delete_PunchLog = async (request, response) => {
    return response.status(500).json({ msg: "not Implemented" });
    const { id } = request.body;
    try {
        //await PunchLogService.remove(id);
        return response.send(200).json({ id: id });
    }
    catch (e) {
        return response.send(404).json({ msg: "error to create a PunchLog with that i" });
    }
};
