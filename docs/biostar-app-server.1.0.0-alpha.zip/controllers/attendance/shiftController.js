"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.delete_Shift = exports.edit_Shift = exports.create_Shift = exports.get_Shift = exports.get_all_Shifts = void 0;
const shift_1 = __importDefault(require("../../services/attendance/shift"));
const workSchedule_1 = __importDefault(require("../../services/attendance/workSchedule"));
exports.get_all_Shifts = async (request, response) => {
    const Shifts = await shift_1.default.getAll();
    return response.status(200).json(Shifts);
};
exports.get_Shift = async (request, response) => {
    const { id } = request.params;
    const Shift = await shift_1.default.getById(id);
    if (Shift) {
        return response.status(200).json(Shift);
    }
    return response.status(404).json({ msg: "no Shift with that id" });
};
exports.create_Shift = async (request, response) => {
    const { name, description, type, timeIn, timeOut, minTimeIn, maxTimeOut, gracePeriod, dayOfWeek, scheduleId } = await request.body;
    try {
        let item = {
            id: 0,
            name,
            description,
            type,
            timeIn,
            timeOut,
            minTimeIn,
            maxTimeOut,
            gracePeriod,
            dayOfWeek
        };
        if (!scheduleId) {
            item.scheduleId = await workSchedule_1.default.getById(scheduleId);
        }
        item = await shift_1.default.create(item);
        return response.status(200).json(item);
    }
    catch (e) {
        return response.status(404).json({ msg: "error to create a product with that i", error: e });
    }
};
exports.edit_Shift = async (request, response) => {
    const { id, name, description, type, timeIn, timeOut, minTimeIn, maxTimeOut, gracePeriod, dayOfWeek, scheduleId } = await request.body;
    try {
        let item = await shift_1.default.getById(id);
        item.name = name;
        item.description = description;
        item.type = type;
        item.timeIn = timeIn;
        item.timeOut = timeOut;
        item.minTimeIn = minTimeIn;
        item.maxTimeOut = maxTimeOut;
        item.gracePeriod = gracePeriod;
        item.dayOfWeek = dayOfWeek;
        item = await shift_1.default.create(item);
        return response.status(200).json(item);
    }
    catch (e) {
        return response.status(404).json({ msg: "error to create a product with that i", error: e });
    }
};
exports.delete_Shift = async (request, response) => {
    return response.status(500).json({ msg: "not Implemented" });
    const { id } = request.body;
    try {
        //await productervice.remove(id);
        return response.send(200).json({ id: id });
    }
    catch (e) {
        return response.send(404).json({ msg: "error to create a order with that i" });
    }
};
