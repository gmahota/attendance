"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.delete_UserDepartment = exports.create_UserDepartment = exports.get_UserDepartment = exports.get_all_UserDepartments = void 0;
const userDepartment_1 = __importDefault(require("../../services/attendance/userDepartment"));
exports.get_all_UserDepartments = async (request, response) => {
    const UserDepartments = await userDepartment_1.default.getAll();
    return response.status(200).json(UserDepartments);
};
exports.get_UserDepartment = async (request, response) => {
    const { id } = request.params;
    console.log(id);
    const UserDepartment = await userDepartment_1.default.getById(id);
    if (UserDepartment) {
        return response.status(200).json(UserDepartment);
    }
    return response.status(404).json({ msg: "no UserDepartment with that id" });
};
exports.create_UserDepartment = async (request, response) => {
    const { id, name, scheduleId } = await request.body;
    try {
        let item = {
            id,
            name,
        };
        item = await userDepartment_1.default.create(item);
        return response.status(200).json(item);
    }
    catch (e) {
        return response.status(404).json({ msg: "error to create a product with that i", error: e });
    }
};
exports.delete_UserDepartment = async (request, response) => {
    return response.status(500).json({ msg: "not Implemented" });
    const { id } = request.body;
    try {
        //await productervice.remove(id);
        return response.send(200).json({ id: id });
    }
    catch (e) {
        return response.send(404).json({ msg: "error to create a order with that i" });
    }
};
