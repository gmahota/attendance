"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.delete_UserGroup = exports.create_UserGroup = exports.get_UserGroup = exports.get_all_UserGroups = void 0;
const userGroup_1 = __importDefault(require("../../services/attendance/userGroup"));
exports.get_all_UserGroups = async (request, response) => {
    const UserGroups = await userGroup_1.default.getAll();
    return response.status(200).json(UserGroups);
};
exports.get_UserGroup = async (request, response) => {
    const { id } = request.params;
    const UserGroup = await userGroup_1.default.getById(id);
    if (UserGroup) {
        return response.status(200).json(UserGroup);
    }
    return response.status(404).json({ msg: "no UserGroup with that id" });
};
exports.create_UserGroup = async (request, response) => {
    const { name, scheduleId } = await request.body;
    try {
        let item = {
            id: 0,
            name,
            scheduleId
        };
        item = await userGroup_1.default.create(item);
        return response.status(200).json(item);
    }
    catch (e) {
        return response.status(404).json({ msg: "error to create a product with that i", error: e });
    }
};
exports.delete_UserGroup = async (request, response) => {
    return response.status(500).json({ msg: "not Implemented" });
    const { id } = request.body;
    try {
        //await productervice.remove(id);
        return response.send(200).json({ id: id });
    }
    catch (e) {
        return response.send(404).json({ msg: "error to create a order with that i" });
    }
};
