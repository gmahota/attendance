"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.delete_WorkSchedule = exports.edit_WorkSchedule = exports.create_WorkSchedule = exports.get_WorkSchedule = exports.get_all_WorkSchedules = void 0;
const workSchedule_1 = __importDefault(require("../../services/attendance/workSchedule"));
exports.get_all_WorkSchedules = async (request, response) => {
    const WorkSchedules = await workSchedule_1.default.getAll();
    return response.status(200).json(WorkSchedules);
};
exports.get_WorkSchedule = async (request, response) => {
    const { id } = request.params;
    const WorkSchedule = await workSchedule_1.default.getById(id);
    if (WorkSchedule) {
        return response.status(200).json(WorkSchedule);
    }
    return response.status(404).json({ msg: "no WorkSchedule with that id" });
};
exports.create_WorkSchedule = async (request, response) => {
    const { name, type } = await request.body;
    try {
        let item = {
            id: 0,
            name,
            type
        };
        item = await workSchedule_1.default.create(item);
        return response.status(200).json(item);
    }
    catch (e) {
        return response.status(404).json({ msg: "error to create a product with that i", error: e });
    }
};
exports.edit_WorkSchedule = async (request, response) => {
    const { id, name, type } = await request.body;
    try {
        let item = await workSchedule_1.default.getById(id);
        item.name = name;
        item.type = type;
        item = await workSchedule_1.default.create(item);
        return response.status(200).json(item);
    }
    catch (e) {
        return response.status(404).json({ msg: "error to create a product with that i", error: e });
    }
};
exports.delete_WorkSchedule = async (request, response) => {
    return response.status(500).json({ msg: "not Implemented" });
    const { id } = request.body;
    try {
        //await productervice.remove(id);
        return response.send(200).json({ id: id });
    }
    catch (e) {
        return response.send(404).json({ msg: "error to create a order with that i" });
    }
};
