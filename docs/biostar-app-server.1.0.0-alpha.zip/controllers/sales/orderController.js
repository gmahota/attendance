"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.delete_order = exports.create_order = exports.get_order = exports.get_all_orders = void 0;
const order_1 = __importDefault(require("../../services/sales/order"));
exports.get_all_orders = async (request, response) => {
    const orders = await order_1.default.getAll();
    return response.status(200).json(orders);
};
exports.get_order = async (request, response) => {
    const { id } = request.params;
    const order = await order_1.default.getById(id);
    if (order) {
        return response.status(200).json(order);
    }
    return response.status(404).json({ msg: "no order with that id" });
};
exports.create_order = async (request, response) => {
    const { code, date, customer, name, vat, status, total, items, } = await request.body;
    try {
        let order = {
            id: 0,
            date,
            code,
            customer,
            name,
            vat,
            status,
            total,
            items,
        };
        order = await order_1.default.create(order);
        return response.status(200).json(order);
    }
    catch (e) {
        return response.status(404).json({ msg: "error to create a order with that i", error: e });
    }
};
exports.delete_order = async (request, response) => {
    return response.status(500).json({ msg: "not Implemented" });
    const { id } = request.body;
    try {
        //await orderService.remove(id);
        return response.send(200).json({ id: id });
    }
    catch (e) {
        return response.send(404).json({ msg: "error to create a order with that i" });
    }
};
