"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.delete_order = exports.create_payment = exports.get_payment = exports.get_all_payments = void 0;
const payment_1 = __importDefault(require("../../services/sales/payment"));
const order_1 = __importDefault(require("../../services/sales/order"));
exports.get_all_payments = async (request, response) => {
    const Payment = await payment_1.default.getAll();
    return response.status(200).json(Payment);
};
exports.get_payment = async (request, response) => {
    const { id } = request.body;
    const payment = await payment_1.default.getById(id);
    if (payment) {
        return response.status(200).json(payment);
    }
    return response.status(404).json({ msg: "no payment with that id" });
};
exports.create_payment = async (request, response) => {
    const { date, phoneNumber, reference, transaction, amount, type, status, orderId, } = await request.body;
    try {
        const order = await order_1.default.getById(orderId);
        let payment = {
            id: 0,
            date,
            phoneNumber,
            reference,
            transaction,
            amount,
            type,
            status,
            order
        };
        payment = await payment_1.default.create(payment);
        return response.status(200).json(payment);
    }
    catch (e) {
        return response.status(404).json({ msg: "error to create a payment with that i", error: e });
    }
};
exports.delete_order = async (request, response) => {
    return response.status(500).json({ msg: "not Implemented" });
    const { id } = request.body;
    try {
        //await Paymentervice.remove(id);
        return response.send(200).json({ id: id });
    }
    catch (e) {
        return response.send(404).json({ msg: "error to create a order with that i" });
    }
};
