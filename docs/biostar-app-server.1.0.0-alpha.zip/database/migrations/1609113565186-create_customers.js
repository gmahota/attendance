"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCustomers1609113565186 = void 0;
const typeorm_1 = require("typeorm");
class createCustomers1609113565186 {
    async up(queryRunner) {
        await queryRunner.createTable(new typeorm_1.Table({
            name: 'customers',
            columns: [
                {
                    name: 'id',
                    type: 'varchar(20)',
                    isPrimary: true
                },
                {
                    name: 'name',
                    type: 'varchar(50)',
                    isNullable: true
                },
                {
                    name: 'address',
                    type: 'varchar(50)',
                    isNullable: true
                },
                {
                    name: 'vat',
                    type: 'varchar(20)',
                    isNullable: true
                },
                {
                    name: 'phoneNumber',
                    type: 'varchar(20)',
                    isNullable: false
                }
            ]
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropTable("customers");
    }
}
exports.createCustomers1609113565186 = createCustomers1609113565186;
