"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createOrders1609317050663 = void 0;
const typeorm_1 = require("typeorm");
class createOrders1609317050663 {
    async up(queryRunner) {
        await queryRunner.createTable(new typeorm_1.Table({
            name: 'orders',
            columns: [
                {
                    name: 'id',
                    type: 'int',
                    isPrimary: true,
                },
                {
                    name: 'date',
                    type: 'datetime',
                    isNullable: false
                },
                {
                    name: 'name',
                    type: 'varchar(50)',
                    isNullable: false
                },
                {
                    name: 'province',
                    type: 'varchar(20)',
                    isNullable: true
                },
                {
                    name: 'phoneNumber',
                    type: 'varchar(20)',
                    isNullable: false
                },
                {
                    name: 'status',
                    type: 'nvarchar(10)',
                    isNullable: true
                }
            ]
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropTable("orders");
    }
}
exports.createOrders1609317050663 = createOrders1609317050663;
