"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPaymentsMpesaLogs1609359172763 = void 0;
const typeorm_1 = require("typeorm");
class createPaymentsMpesaLogs1609359172763 {
    async up(queryRunner) {
        await queryRunner.createTable(new typeorm_1.Table({
            name: 'paymentMpesaLogs',
            columns: [
                {
                    name: 'id',
                    type: 'int',
                    isPrimary: true
                },
                {
                    name: 'date',
                    type: 'datetime',
                    isNullable: false
                },
                {
                    name: 'conversation',
                    type: 'varchar(50)',
                    isNullable: true
                },
                {
                    name: 'transaction',
                    type: 'varchar(20)',
                    isNullable: true
                },
                {
                    name: 'statusText',
                    type: 'varchar(20)',
                    isNullable: false
                },
                {
                    name: 'status',
                    type: 'nvarchar(20)',
                    isNullable: true
                },
                {
                    name: 'reference',
                    type: 'varchar(50)',
                    isNullable: true
                },
                {
                    name: 'outputError',
                    type: 'varchar(50)',
                    isNullable: true
                },
            ]
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropTable("paymentMpesaLogs");
    }
}
exports.createPaymentsMpesaLogs1609359172763 = createPaymentsMpesaLogs1609359172763;
