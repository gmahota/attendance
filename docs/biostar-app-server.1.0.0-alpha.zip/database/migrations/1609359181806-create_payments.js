"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPayments1609359181806 = void 0;
const typeorm_1 = require("typeorm");
class createPayments1609359181806 {
    async up(queryRunner) {
        await queryRunner.createTable(new typeorm_1.Table({
            name: 'payments',
            columns: [
                {
                    name: 'id',
                    type: 'int',
                    isPrimary: true
                },
                {
                    name: 'date',
                    type: 'datetime',
                    isNullable: false
                },
                {
                    name: 'phoneNumber',
                    type: 'varchar(20)',
                    isNullable: false
                },
                {
                    name: 'reference',
                    type: 'varchar(50)',
                    isNullable: true
                },
                {
                    name: 'transaction',
                    type: 'varchar(50)',
                    isNullable: false
                },
                {
                    name: 'amount',
                    type: 'float'
                },
                {
                    name: 'type',
                    type: 'varchar(10)',
                    isNullable: true
                },
                {
                    name: 'status',
                    type: 'varchar(10)',
                    isNullable: true
                },
                {
                    name: 'order_id',
                    type: 'int',
                    isNullable: true
                },
                {
                    name: 'paymentMpesaLogs_id',
                    type: 'int',
                    isNullable: true
                },
            ],
            foreignKeys: [
                {
                    name: 'PaymentOrder',
                    columnNames: ['order_id'],
                    referencedTableName: 'orders',
                    referencedColumnNames: ['id'],
                    onUpdate: 'CASCADE',
                    onDelete: 'CASCADE'
                },
                {
                    name: 'PaymentMpesaLog',
                    columnNames: ['paymentMpesaLogs_id'],
                    referencedTableName: 'paymentMpesaLogs',
                    referencedColumnNames: ['id'],
                    onUpdate: 'CASCADE',
                    onDelete: 'CASCADE'
                }
            ]
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropTable("payments");
    }
}
exports.createPayments1609359181806 = createPayments1609359181806;
