"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const ts_simple_nameof_1 = require("ts-simple-nameof");
const typeorm_1 = require("typeorm");
const order_1 = __importDefault(require("./order"));
const paymentMpesaLog_1 = __importDefault(require("./paymentMpesaLog"));
let Payment = class Payment {
    constructor() {
        this.date = new Date();
    }
};
__decorate([
    typeorm_1.PrimaryGeneratedColumn('increment'),
    __metadata("design:type", Number)
], Payment.prototype, "id", void 0);
__decorate([
    typeorm_1.Column(),
    __metadata("design:type", Date)
], Payment.prototype, "date", void 0);
__decorate([
    typeorm_1.Column({ length: 20, nullable: false }),
    __metadata("design:type", String)
], Payment.prototype, "phoneNumber", void 0);
__decorate([
    typeorm_1.Column(),
    __metadata("design:type", Number)
], Payment.prototype, "reference", void 0);
__decorate([
    typeorm_1.Column(),
    __metadata("design:type", Number)
], Payment.prototype, "transaction", void 0);
__decorate([
    typeorm_1.Column(),
    __metadata("design:type", Number)
], Payment.prototype, "amount", void 0);
__decorate([
    typeorm_1.Column({ length: 10, nullable: true }),
    __metadata("design:type", String)
], Payment.prototype, "type", void 0);
__decorate([
    typeorm_1.Column({ length: 20, nullable: true }),
    __metadata("design:type", String)
], Payment.prototype, "status", void 0);
__decorate([
    typeorm_1.OneToOne(() => order_1.default),
    typeorm_1.JoinColumn({ name: "order_id" }),
    __metadata("design:type", order_1.default)
], Payment.prototype, "order", void 0);
__decorate([
    typeorm_1.OneToOne(() => paymentMpesaLog_1.default),
    typeorm_1.JoinColumn({
        name: ts_simple_nameof_1.nameof((p) => p.id),
        referencedColumnName: ts_simple_nameof_1.nameof((u) => u.id),
    }),
    __metadata("design:type", paymentMpesaLog_1.default)
], Payment.prototype, "paymentMpesaLog", void 0);
Payment = __decorate([
    typeorm_1.Entity("payments"),
    __metadata("design:paramtypes", [])
], Payment);
exports.default = Payment;
