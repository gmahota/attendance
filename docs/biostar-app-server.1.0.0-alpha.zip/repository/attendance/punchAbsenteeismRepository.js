"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const punchAbsenteeism_1 = __importDefault(require("../../models/attendance/punchAbsenteeism"));
const typeorm_1 = require("typeorm");
const moment_1 = __importDefault(require("moment"));
const findByDate = async function findByDate(date) {
    const PunchAbsenteeismRepository = typeorm_1.getRepository(punchAbsenteeism_1.default);
    const item = await PunchAbsenteeismRepository.findOneOrFail({
        where: { date: Date }
    });
    return item;
};
const findAll = async function findAll(filter) {
    const entityManager = typeorm_1.getManager();
    let str_where = "";
    if (filter === null || filter === void 0 ? void 0 : filter.user) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `userId = '${filter.user}'`;
    }
    if (filter === null || filter === void 0 ? void 0 : filter.department) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `userDepartment = '${filter.department}'`;
    }
    if (filter === null || filter === void 0 ? void 0 : filter.group) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `userGroup = '${filter.group}'`;
    }
    if ((filter === null || filter === void 0 ? void 0 : filter.dateBegin) && (filter === null || filter === void 0 ? void 0 : filter.dateEnd)) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `Date(v.date)  BETWEEN  '${moment_1.default(filter.dateBegin).format("YYYY-MM-DD")}'
      and '${moment_1.default(filter.dateEnd).format("YYYY-MM-DD")}'`;
    }
    if (filter === null || filter === void 0 ? void 0 : filter.date) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `date = '${filter.date}'`;
    }
    str_where = str_where.length === 0 ? "" : " where " + str_where;
    const str_query = `CALL getAbsenteeism(0,1,0,'${moment_1.default(filter.dateBegin).format("YYYY-MM-DD")}', '${moment_1.default(filter.dateEnd).format("YYYY-MM-DD")}')`;
    const items = await entityManager.query(str_query);
    return items[0];
};
const findAll_Absenteeism = async function findAll_Absenteeism(filter) {
    const entityManager = typeorm_1.getManager();
    let str_where = "";
    if (filter === null || filter === void 0 ? void 0 : filter.user) {
        str_where += str_where.length === 0 ?
            `userId = '${filter.user}'` :
            ` and userId = '${filter.user}'`;
    }
    if (filter === null || filter === void 0 ? void 0 : filter.date) {
        str_where += str_where.length === 0 ?
            `date = '${filter.date}'` :
            ` and date = '${filter.date}'`;
    }
    if ((filter === null || filter === void 0 ? void 0 : filter.dateBegin) && (filter === null || filter === void 0 ? void 0 : filter.dateEnd)) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `Date(v.date)  BETWEEN  '${moment_1.default(filter.dateBegin).format("YYYY-MM-DD")}'
      and '${moment_1.default(filter.dateEnd).format("YYYY-MM-DD")}'`;
    }
    str_where = str_where.length === 0 ? "" : " where " + str_where;
    const items = await entityManager.query(`CALL getAbsenteeism(0,1,0,'${moment_1.default(filter.dateBegin).format("YYYY-MM-DD")}', '${moment_1.default(filter.dateEnd).format("YYYY-MM-DD")}')`);
    return items[0];
};
exports.default = {
    findByDate,
    findAll,
    findAll_Absenteeism
};
