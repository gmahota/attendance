"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const punchDailyCard_1 = __importDefault(require("../../models/attendance/punchDailyCard"));
const typeorm_1 = require("typeorm");
const moment_1 = __importDefault(require("moment"));
const findByDate = async function findByDate(date) {
    const PunchDailyCardRepository = typeorm_1.getRepository(punchDailyCard_1.default);
    const item = await PunchDailyCardRepository.findOneOrFail({
        where: { date: Date }
    });
    return item;
};
const findAll = async function findAll(filter) {
    const entityManager = typeorm_1.getManager();
    let str_where = "";
    if (filter === null || filter === void 0 ? void 0 : filter.user) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `userId = '${filter.user}'`;
    }
    if (filter === null || filter === void 0 ? void 0 : filter.department) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `userDepartment = '${filter.department}'`;
    }
    if (filter === null || filter === void 0 ? void 0 : filter.group) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `userGroup = '${filter.group}'`;
    }
    if ((filter === null || filter === void 0 ? void 0 : filter.dateBegin) && (filter === null || filter === void 0 ? void 0 : filter.dateEnd)) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `Date(v.date)  BETWEEN  '${moment_1.default(filter.dateBegin).format("YYYY-MM-DD")}'
      and '${moment_1.default(filter.dateEnd).format("YYYY-MM-DD")}'`;
    }
    if (filter === null || filter === void 0 ? void 0 : filter.date) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `date = '${moment_1.default(filter.date).format("YYYY-MM-DD")}'`;
    }
    str_where = str_where.length === 0 ? "" : " where " + str_where;
    const str_query = `SELECT
    ROW_NUMBER() OVER(PARTITION BY userId) as id,
    v.*,g.name as userGroupName
    FROM view_PunchDaily v
    left join userGroup g on g.id = v.userGroup
    ${str_where}

  order by v.date asc, v.username asc
  `;
    console.log(str_query);
    const items = await entityManager.query(str_query);
    return items;
};
const findAll_Punchlog = async function findAll_Punchlog(filter) {
    const entityManager = typeorm_1.getManager();
    let str_where = "";
    if (filter === null || filter === void 0 ? void 0 : filter.user) {
        str_where += str_where.length === 0 ?
            `userId = '${filter.user}'` :
            ` and userId = '${filter.user}'`;
    }
    if (filter === null || filter === void 0 ? void 0 : filter.date) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `date = '${moment_1.default(filter.date).format("YYYY-MM-DD")}'`;
    }
    if ((filter === null || filter === void 0 ? void 0 : filter.dateBegin) && (filter === null || filter === void 0 ? void 0 : filter.dateEnd)) {
        str_where += str_where.length === 0 ? "" : " and ";
        str_where += `Date(v.date)  BETWEEN  '${moment_1.default(filter.dateBegin).format("YYYY-MM-DD")}'
      and '${moment_1.default(filter.dateEnd).format("YYYY-MM-DD")}'`;
    }
    str_where = str_where.length === 0 ? "" : " where " + str_where;
    const str_query = `SELECT
    ROW_NUMBER() OVER(PARTITION BY userId) as id,
    v.*,g.name as userGroupName
    FROM View_PunchCard v
    left join userGroup g on g.id = v.userGroup
    ${str_where}
  `;
    const items = await entityManager.query(str_query);
    return items;
};
exports.default = {
    findByDate,
    findAll,
    findAll_Punchlog
};
