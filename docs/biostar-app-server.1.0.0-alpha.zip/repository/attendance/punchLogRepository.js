"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const punchLog_1 = __importDefault(require("../../models/attendance/punchLog"));
const typeorm_1 = require("typeorm");
const findById = async function findById(id) {
    const PunchLogRepository = typeorm_1.getRepository(punchLog_1.default);
    const item = await PunchLogRepository.findOneOrFail({
        where: { id: id }
    });
    return item;
};
const findAll = async function findAll() {
    const PunchLogRepository = typeorm_1.getRepository(punchLog_1.default);
    const PunchLogs = await PunchLogRepository.find({
        order: {
            date: "ASC"
        }
    });
    return PunchLogs;
};
const create = async function create(item) {
    const PunchLogRepository = typeorm_1.getRepository(punchLog_1.default);
    const data = PunchLogRepository.create(item);
    await PunchLogRepository.save(data);
    return data;
};
exports.default = {
    create,
    findById,
    findAll
};
