"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const shift_1 = __importDefault(require("../../models/attendance/shift"));
const typeorm_1 = require("typeorm");
const findById = async function findById(id) {
    const ShiftRepository = typeorm_1.getRepository(shift_1.default);
    const data = await ShiftRepository.findOneOrFail({
        where: { id: id }
    });
    return data;
};
const findAll = async function findAll() {
    const ShiftRepository = typeorm_1.getRepository(shift_1.default);
    const data = await ShiftRepository.find({
        order: {
            name: "ASC",
            id: "DESC",
        },
    });
    return data;
};
const create = async function create(data) {
    const ShiftRepository = typeorm_1.getRepository(shift_1.default);
    await ShiftRepository.save(data);
    return data;
};
exports.default = {
    create,
    findAll,
    findById
};
