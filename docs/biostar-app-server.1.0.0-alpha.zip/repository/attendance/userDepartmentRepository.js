"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const userDepartment_1 = __importDefault(require("../../models/attendance/userDepartment"));
const typeorm_1 = require("typeorm");
const findById = async function findById(id) {
    const UserRepository = typeorm_1.getRepository(userDepartment_1.default);
    const data = await UserRepository.findOneOrFail({
        where: { id: id }
    });
    return data;
};
const findAll = async function findAll() {
    const UserRepository = typeorm_1.getRepository(userDepartment_1.default);
    const data = await UserRepository.find({
        order: {
            name: "ASC",
            id: "DESC",
        },
    });
    return data;
};
const create = async function create(data) {
    const UserRepository = typeorm_1.getRepository(userDepartment_1.default);
    await UserRepository.save(data);
    return data;
};
exports.default = {
    create,
    findAll,
    findById
};
