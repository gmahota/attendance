"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const userGroup_1 = __importDefault(require("../../models/attendance/userGroup"));
const typeorm_1 = require("typeorm");
const findById = async function findById(id) {
    const UserRepository = typeorm_1.getRepository(userGroup_1.default);
    const data = await UserRepository.findOneOrFail({
        where: { id: id }
    });
    return data;
};
const findAll = async function findAll() {
    const UserRepository = typeorm_1.getRepository(userGroup_1.default);
    const data = await UserRepository.find({
        order: {
            id: "ASC",
        },
    });
    return data;
};
const create = async function create(data) {
    const UserRepository = typeorm_1.getRepository(userGroup_1.default);
    await UserRepository.save(data);
    return data;
};
exports.default = {
    create,
    findAll,
    findById
};
