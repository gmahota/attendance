"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const user_1 = __importDefault(require("../../models/attendance/user"));
const typeorm_1 = require("typeorm");
const findById = async function findById(id) {
    const UserRepository = typeorm_1.getRepository(user_1.default);
    const data = await UserRepository.findOneOrFail({
        where: { id: id },
        relations: ["userGroup", "schedule", "department"]
    });
    return data;
};
const findAll = async function findAll(filter) {
    const UserRepository = typeorm_1.getRepository(user_1.default);
    const data = await UserRepository.find({
        where: "",
        relations: ["userGroup", "schedule", "department"],
        order: {
            name: "ASC",
            id: "DESC",
        },
    });
    return data;
};
const create = async function create(data) {
    const UserRepository = typeorm_1.getRepository(user_1.default);
    await UserRepository.save(data);
    return data;
};
exports.default = {
    create,
    findAll,
    findById
};
