"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const workSchedule_1 = __importDefault(require("../../models/attendance/workSchedule"));
const typeorm_1 = require("typeorm");
const findById = async function findById(id) {
    const WorkScheduleRepository = typeorm_1.getRepository(workSchedule_1.default);
    const data = await WorkScheduleRepository.findOneOrFail({
        where: { id: id },
        relations: ["Shifts", "users",
            "users.userGroup",
            "users.schedule",
            "users.department",
            "groups"
        ]
    });
    return data;
};
const findAll = async function findAll() {
    const WorkScheduleRepository = typeorm_1.getRepository(workSchedule_1.default);
    const data = await WorkScheduleRepository.find({
        order: {
            id: "ASC",
        },
    });
    return data;
};
const create = async function create(data) {
    const WorkScheduleRepository = typeorm_1.getRepository(workSchedule_1.default);
    await WorkScheduleRepository.save(data);
    return data;
};
exports.default = {
    create,
    findAll,
    findById
};
