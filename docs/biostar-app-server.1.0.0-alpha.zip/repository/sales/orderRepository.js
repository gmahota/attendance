"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const order_1 = __importDefault(require("../../models/sales/order"));
const typeorm_1 = require("typeorm");
const findById = async function findById(id) {
    const OrderRepository = typeorm_1.getRepository(order_1.default);
    const order = await OrderRepository.findOneOrFail({
        relations: ['items'],
        where: { id: id }
    });
    return order;
};
const findAll = async function findAll() {
    const OrderRepository = typeorm_1.getRepository(order_1.default);
    const Orders = await OrderRepository.find({
        order: {
            name: "ASC",
            id: "DESC",
        }
    });
    return Orders;
};
const findByPhoneNumber = async function findByPhoneNumber(phoneNumber) {
    const OrderRepository = typeorm_1.getRepository(order_1.default);
    const Orders = await OrderRepository.find({
        where: { phoneNumber: phoneNumber },
        order: {
            name: "ASC",
            id: "DESC",
        },
    });
    return Orders;
};
const create = async function create(order) {
    const OrderRepository = typeorm_1.getRepository(order_1.default);
    const data = OrderRepository.create(order);
    await OrderRepository.save(data);
    return data;
};
exports.default = {
    create,
    findById,
    findAll,
    findByPhoneNumber,
};
