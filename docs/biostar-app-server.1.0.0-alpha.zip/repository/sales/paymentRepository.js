"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const payment_1 = __importDefault(require("../../models/sales/payment"));
const typeorm_1 = require("typeorm");
const paymentMpesaLog_1 = __importDefault(require("../../models/sales/paymentMpesaLog"));
const mpesa_1 = __importDefault(require("../../services/mpesa"));
const findById = async function findById(id) {
    const PaymentRepository = typeorm_1.getRepository(payment_1.default);
    const payment = await PaymentRepository.findOneOrFail({
        where: { id: id }
    });
    return payment;
};
const findAll = async function findAll() {
    const PaymentRepository = typeorm_1.getRepository(payment_1.default);
    const Payments = await PaymentRepository.find({
        order: {
            date: "ASC",
            id: "DESC",
        },
    });
    return Payments;
};
const findByPhoneNumber = async function findByName(name) {
    const PaymentRepository = typeorm_1.getRepository(payment_1.default);
    const Payments = await PaymentRepository.find({
        order: {
            date: "ASC",
            id: "DESC",
        },
    });
    return Payments;
};
const create = async function create(payment) {
    try {
        const PaymentRepository = typeorm_1.getRepository(payment_1.default);
        const PaymentMpesaLogRepository = typeorm_1.getRepository(paymentMpesaLog_1.default);
        const mpesaResponse = await mpesa_1.default.set_ReceiveMoney(payment.phoneNumber, payment.reference, payment.reference, payment.amount);
        const mpesaLog = await PaymentMpesaLogRepository.create(Object.assign({}, mpesaResponse));
        await PaymentMpesaLogRepository.save(mpesaLog);
        const sucessStatus = ["201", "200"];
        if (mpesaLog.status == "201" || mpesaLog.status == "200") {
            payment.paymentMpesaLog = mpesaLog;
            payment = await PaymentRepository.create(payment);
            await PaymentRepository.save(payment);
            return payment;
        }
        else {
            throw new Error(JSON.stringify(mpesaLog));
        }
    }
    catch (e) {
        throw e;
    }
};
exports.default = {
    create,
    findById,
    findAll,
    findByPhoneNumber,
};
