"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = __importDefault(require("./middlewares/auth"));
const MpesaController_1 = __importDefault(require("./controllers/MpesaController"));
const userController_1 = require("./controllers/admin/userController");
const authController_1 = __importDefault(require("./controllers/admin/authController"));
const orderController_1 = require("./controllers/sales/orderController");
const paymentController_1 = require("./controllers/sales/paymentController");
const customerController_1 = require("./controllers/base/customerController");
const productController_1 = require("./controllers/base/productController");
const projectController_1 = require("./controllers/base/projectController");
const routes = express_1.Router();
routes.get("/", async (request, response) => {
    response.send("WellCome!");
});
routes.get("/mpesa/receivemoney", MpesaController_1.default.receiveMoney);
routes
    .get("/api/users", userController_1.get_all_users)
    .get("/api/users/:id", userController_1.get_user)
    .post("/api/users", userController_1.create_user)
    .delete("/api/users/:id", userController_1.delete_user)
    .post("/api/auth/login", authController_1.default.login)
    .get("/api/auth/guest", authController_1.default.guest)
    .get("/api/auth/auth", auth_1.default, authController_1.default.auth)
    .get("/api/orders", orderController_1.get_all_orders)
    .get("/api/orders/:id", orderController_1.get_order)
    .post("/api/orders/", orderController_1.create_order)
    .get("/api/payments", paymentController_1.get_all_payments)
    .get("/api/payments/:id", paymentController_1.get_payment)
    .post("/api/payments/", paymentController_1.create_payment)
    .get("/api/customers", customerController_1.get_all_customers)
    .get("/api/customers/:phonenumber", customerController_1.get_customer)
    .post("/api/customers/", customerController_1.create_customer)
    .get("/api/products", productController_1.get_all_products)
    .get("/api/products/:id", productController_1.get_product)
    .post("/api/products/", productController_1.create_product)
    .get("/api/projects", projectController_1.get_all_projects)
    .get("/api/projects/:id", projectController_1.get_project)
    .post("/api/projects/", projectController_1.create_project);
exports.default = routes;
