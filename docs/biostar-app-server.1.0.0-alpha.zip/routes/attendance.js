"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const punchLogController_1 = require("../controllers/attendance/punchLogController");
const punchDailyCardController_1 = require("../controllers/attendance/punchDailyCardController");
const userController_1 = require("../controllers/attendance/userController");
const userGroupController_1 = require("../controllers/attendance/userGroupController");
const shiftController_1 = require("../controllers/attendance/shiftController");
const workScheduleController_1 = require("../controllers/attendance/workScheduleController");
const userDepartmentController_1 = require("../controllers/attendance/userDepartmentController");
const attendanceRouter = express_1.Router();
attendanceRouter
    .get("/users", userController_1.get_all_Users)
    .get("/user/:id", userController_1.get_User)
    .post("/user/", userController_1.create_User);
attendanceRouter
    .get("/shifts", shiftController_1.get_all_Shifts)
    .get("/shift/:id", shiftController_1.get_Shift)
    .post("/shift", shiftController_1.create_Shift)
    .post("/shift/:id", shiftController_1.edit_Shift);
attendanceRouter
    .get("/workschedules", workScheduleController_1.get_all_WorkSchedules)
    .get("/workschedule/:id", workScheduleController_1.get_WorkSchedule)
    .post("/workschedule", workScheduleController_1.create_WorkSchedule)
    .post("/workschedule/:id", workScheduleController_1.edit_WorkSchedule);
attendanceRouter
    .get("/usergroups", userGroupController_1.get_all_UserGroups)
    .get("/usergroup/:id", userGroupController_1.get_UserGroup)
    .post("/usergroup/", userGroupController_1.create_UserGroup);
attendanceRouter
    .get("/punchLogs", punchLogController_1.get_all_PunchLogs)
    .get("/punchLog/:id", punchLogController_1.get_PunchLog)
    .post("/punchLog/", punchLogController_1.create_PunchLog);
attendanceRouter
    .post("/punchDailyCards", punchDailyCardController_1.get_all_PunchDailyCards)
    .get("/punchDailyCard/:id", punchDailyCardController_1.get_PunchDailyCard)
    .post("/punchDailyCards/report", punchDailyCardController_1.get_Report);
attendanceRouter
    .get("/userDepartments", userDepartmentController_1.get_all_UserDepartments)
    .get("/userDepartment/:id", userDepartmentController_1.get_UserDepartment)
    .post("/userDepartment/", userDepartmentController_1.create_UserDepartment);
exports.default = attendanceRouter;
