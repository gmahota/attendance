"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const productController_1 = require("../controllers/base/productController");
const baseRouter = express_1.Router();
baseRouter.get("/products", productController_1.get_all_products);
baseRouter.get("/products/:id", productController_1.get_product);
baseRouter.post("/products/", productController_1.create_product);
//Change my password
//router.post("/change-password", [checkJwt], AuthController.changePassword);
exports.default = baseRouter;
