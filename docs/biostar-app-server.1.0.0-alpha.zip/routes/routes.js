"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
// System Routers
const admin_1 = __importDefault(require("./admin"));
const auth_1 = __importDefault(require("./auth"));
const base_1 = __importDefault(require("./base"));
const attendance_1 = __importDefault(require("./attendance"));
const routes = express_1.Router();
/**
 * @swagger
 * /:
 *   get:
 *     summary: Home Page
 *     description: Can be used to testing an API.
*/
routes.get("/", async (request, response) => {
    response.send("WellCome!");
});
routes.use('/api/admin', admin_1.default);
routes.use('/api/auth', auth_1.default);
routes.use('/api/base', base_1.default);
routes.use('/api/attendance', attendance_1.default);
exports.default = routes;
