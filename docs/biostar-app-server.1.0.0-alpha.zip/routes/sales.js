"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const orderController_1 = require("../controllers/sales/orderController");
const salesRouter = express_1.Router();
salesRouter.get("/orders", orderController_1.get_all_orders);
salesRouter.get("/orders/:id", orderController_1.get_order);
salesRouter.post("/orders/", orderController_1.create_order);
exports.default = salesRouter;
