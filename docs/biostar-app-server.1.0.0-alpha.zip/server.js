"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = __importDefault(require("path"));
require("dotenv/config");
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
require("express-async-errors");
const morgan_1 = __importDefault(require("morgan"));
const routes_1 = __importDefault(require("./routes/routes"));
const handler_1 = __importDefault(require("./errors/handler"));
require("./database/connection");
const swagger_ui_express_1 = __importDefault(require("swagger-ui-express"));
const swagger_jsdoc_1 = __importDefault(require("swagger-jsdoc"));
dotenv_1.default.config();
const app = express_1.default();
const swaggerDefinition = {
    openapi: "3.0.0",
    info: {
        title: "Agnus Invoice API",
        version: "1.0.0",
        description: 'This is a REST API application made with Express. It retrieves data from JSONPlaceholder.',
        license: {
            name: 'Licensed Under MIT',
            url: 'https://spdx.org/licenses/MIT.html',
        },
        contact: {
            name: 'Guimarães Mahota',
            url: 'https://github.com/gmahota',
        },
    },
    servers: [
        {
            url: 'http://localhost:5000/api',
            description: 'Development Local PC',
        },
        {
            url: 'https://agnusinvoiceapi.herokuapp.com/api',
            description: 'Development server',
        },
    ]
};
const options = {
    swaggerDefinition,
    // Paths to files containing OpenAPI definitions
    apis: ["./dist/routes/**/*.js"],
};
const swaggerSpec = swagger_jsdoc_1.default(options);
// Constants
const port = process.env.PORT || 5000;
app.use("/api-docs", swagger_ui_express_1.default.serve, swagger_ui_express_1.default.setup(swaggerSpec));
app.use(cors_1.default());
app.use(express_1.default.json());
app.use(routes_1.default);
app.use(express_1.default.static('./public'));
app.use("/uploads", express_1.default.static(path_1.default.join(__dirname, "..", "uploads")));
app.use(handler_1.default);
app.use(morgan_1.default('combined'));
app.listen(port);
