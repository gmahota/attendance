"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const punchDailyCard_View_1 = __importDefault(require("../../view/attendance/punchDailyCard_View"));
const punchDailyCardRepository_1 = __importDefault(require("../../repository/attendance/punchDailyCardRepository"));
const punchLogExcel_1 = __importDefault(require("../../services/attendance/punchLogExcel"));
const punchTotalHoursRepository_1 = __importDefault(require("../../repository/attendance/punchTotalHoursRepository"));
const punchAbsenteeismRepository_1 = __importDefault(require("../../repository/attendance/punchAbsenteeismRepository"));
const getAll = (filter) => punchDailyCardRepository_1.default.findAll(filter);
const getByDate = (date) => punchDailyCardRepository_1.default.findByDate(date);
const getReport = async (filter) => {
    let filterRender = {
        department: filter.department || "",
        group: filter.group || "",
        user: filter.user || "",
        dateBegin: new Date(filter.dateBegin || 0),
        dateEnd: new Date(filter.dateEnd || 0),
    };
    switch (filter.type) {
        case "Punchdaily":
            const items = await punchDailyCardRepository_1.default.findAll(Object.assign({}, filterRender));
            let items_render = punchDailyCard_View_1.default.renderMany(items);
            punchLogExcel_1.default.fillPunchDaily(items_render);
            return "uploads/attendance/punchdaily.xlsx";
        case "Punchlog":
            const punchs = await punchDailyCardRepository_1.default.findAll_Punchlog(Object.assign({}, filterRender));
            punchLogExcel_1.default.fillPunchCard(punchs);
            return "uploads/attendance/punchlog.xlsx";
        case "PunchTotalHours":
            const workhrs = await punchTotalHoursRepository_1.default.findAll(Object.assign({}, filterRender));
            punchLogExcel_1.default.fillTotalHours(workhrs);
            return "uploads/attendance/punchtotal.xlsx";
        case "PunchAbsenteeism":
            const absent = await punchAbsenteeismRepository_1.default.findAll(Object.assign({}, filterRender));
            punchLogExcel_1.default.fillAbsenteeism(absent);
            return "uploads/attendance/punchabsent.xlsx";
    }
};
exports.default = {
    getAll,
    getReport, getByDate
};
