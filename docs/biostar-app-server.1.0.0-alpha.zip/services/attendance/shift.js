"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const shiftRepository_1 = __importDefault(require("../../repository/attendance/shiftRepository"));
const getById = (id) => shiftRepository_1.default.findById(id);
const getAll = () => shiftRepository_1.default.findAll();
const create = (item) => shiftRepository_1.default.create(item);
exports.default = {
    getAll,
    getById,
    create
};
