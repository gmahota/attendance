"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mpesa_1 = require("@paymentsds/mpesa");
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const client = new mpesa_1.Client({
    apiKey: process.env.Mpesa_ApiKey,
    publicKey: process.env.Mpesa_PublicKey,
    serviceProviderCode: process.env.Mpesa_ServiceProviderCode,
    verifySSL: false,
    debugging: true,
});
const set_ReceiveMoney = async (from, reference, transaction, amount) => {
    let response = {};
    const paymentData = {
        from: from,
        reference: reference,
        transaction: transaction,
        amount: amount,
    };
    await client.receive(paymentData).then((r) => {
        response = r.response;
        response.conversation = r.conversation;
        response.transaction = r.transaction;
        response.reference = r.reference;
        // Handle success scenario
    }).catch((e) => {
        response = e.response;
        //throw e;
    });
    return response;
};
exports.default = {
    set_ReceiveMoney,
};
