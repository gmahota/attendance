"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const orderRepository_1 = __importDefault(require("../../repository/sales/orderRepository"));
const getById = (id) => orderRepository_1.default.findById(id);
const getAll = () => orderRepository_1.default.findAll();
const create = (order) => orderRepository_1.default.create(order);
const getByPhoneNumber = (phoneNumber) => orderRepository_1.default.findByPhoneNumber(phoneNumber);
exports.default = {
    getAll,
    getById,
    create,
    getByPhoneNumber,
};
