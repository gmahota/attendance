"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const paymentRepository_1 = __importDefault(require("../../repository/sales/paymentRepository"));
const getById = (id) => paymentRepository_1.default.findById(id);
const getAll = () => paymentRepository_1.default.findAll();
const create = (Payment) => paymentRepository_1.default.create(Payment);
const getByPhoneNumber = (phoneNumber) => paymentRepository_1.default.findByPhoneNumber(phoneNumber);
exports.default = {
    getAll,
    getById,
    create,
    getByPhoneNumber,
};
