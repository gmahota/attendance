"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const moment_1 = __importDefault(require("moment"));
exports.default = {
    render(item) {
        let totalDelay = "";
        if (!item.delayOut && !item.delayEntrance) {
            const a = moment_1.default.duration(item.delayOut);
            const b = moment_1.default.duration(item.delayEntrance);
            const c = a.add(b);
            totalDelay = [
                ('0' + c.hours()).slice(-2),
                ('0' + c.minutes()).slice(-2),
                ('0' + c.seconds()).slice(-2),
            ].join(':');
        }
        return Object.assign(Object.assign({}, item), { totalDelay });
    },
    renderMany(items) {
        return items === null || items === void 0 ? void 0 : items.map(item => this.render(item));
    },
};
